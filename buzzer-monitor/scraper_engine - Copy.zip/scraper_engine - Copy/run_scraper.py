import sys
import json
import mysql.connector
from datetime import datetime

DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",        
    "password": "",        
    "database": "buzzer_monitor" 
}

platform = sys.argv[1] if len(sys.argv) > 1 else "youtube"
url = sys.argv[2] if len(sys.argv) > 2 else ""
task_id = sys.argv[3] if len(sys.argv) > 3 else 1

data = []

try:
    if platform == "youtube":
        from youtube_scraper import scrape_youtube
        data = scrape_youtube(url)
    elif platform == "tiktok":
        from tiktok_scraper import scrape_tiktok
        data = scrape_tiktok(url)
except Exception as e:
    # Jangan print error di sini agar tidak merusak JSON
    pass

if len(data) > 0:
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Mapping kolom sesuai error database sebelumnya
        query = f"INSERT INTO comments (task_id, username, content, platform, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s)"
        
        for item in data:
            val_user = item.get('user', 'Anonymous')
            val_text = item.get('text', 'Kosong')
            cursor.execute(query, (task_id, val_user, val_text, platform, now, now))
        
        cursor.execute("UPDATE tasks SET status = 'completed', updated_at = %s WHERE id = %s", (now, task_id))
        conn.commit()
        cursor.close()
        conn.close()
        
        # HANYA PRINT SATU BARIS INI DI AKHIR
        print(json.dumps(data))
    except Exception as e:
        print(json.dumps([]))
else:
    print(json.dumps([]))