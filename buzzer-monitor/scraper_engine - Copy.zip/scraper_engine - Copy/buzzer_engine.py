import numpy as np
import joblib
from ml_classifier import RandomForestClassifier
from graph_analyzer import CommunityDetector
from narrative_analyzer import NarrativeIntelligence

class BuzzerEngineV4:
    def __init__(self):
        # Load model yang sudah dilatih (Fase 3: Hybrid Scoring)
        self.model = joblib.load('scraper_engine/buzzer_model.pkl')
        self.scaler = joblib.load('scraper_engine/scaler.pkl')
        self.narrative_ai = NarrativeIntelligence()

    def analyze_comments(self, comments_data):
        features_list = []
        
        for comment in comments_data:
            # Fase 2: Feature Engineering (18-Dimensional Vector)
            features = [
                self._get_semantic_score(comment),
                self._get_temporal_anomaly(comment),
                self._get_username_entropy(comment['username']),
                # ... total 18 fitur
            ]
            features_list.append(features)

        # Fase 3: Hybrid Scoring (70% Heuristik, 30% ML)
        ml_probs = self.model.predict_proba(self.scaler.transform(features_list))[:, 1]
        
        final_results = []
        for i, prob in enumerate(ml_probs):
            heuristic_score = self._calculate_heuristic(comments_data[i])
            # Gabungkan skor sesuai modul
            final_score = (0.7 * heuristic_score) + (0.3 * (prob * 100))
            final_results.append({
                'id': comments_data[i]['id'],
                'score': final_score,
                'is_buzzer': final_score > 75 # Threshold
            })
            
        return final_results

    def _get_username_entropy(self, username):
        # Implementasi Username Entropy (Fase 2.7)
        return len(set(username)) / len(username) if len(username) > 0 else 0