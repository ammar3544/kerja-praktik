# scraper_engine/graph_analyzer.py
import networkx as nx

class BehaviorAnalyzer:
    def __init__(self):
        self.G = nx.Graph()

    def analyze_network(self, comments_df):
        # 2.2 Graph Intelligence: Pemetaan komunitas
        # Hubungkan user yang membalas thread yang sama atau menyebut user lain
        for _, row in comments_df.iterrows():
            self.G.add_edge(row['username'], row['video_id'])
        
        # Centrality score menunjukkan seberapa 'pusat' akun ini dalam jaringan
        centrality = nx.degree_centrality(self.G)
        return centrality

    def get_temporal_features(self, timestamps):
        # 2.5 Advanced Temporal Forensics: Deteksi Burst/Spike
        # Menghitung densitas komentar dalam rentang menit yang sama
        import pandas as pd
        ts = pd.to_datetime(timestamps)
        velocity = ts.diff().dt.total_seconds().mean() # Jarak rata-rata antar komentar
        return [velocity]