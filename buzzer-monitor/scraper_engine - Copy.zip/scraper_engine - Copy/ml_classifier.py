# 2.7 Username Entropy: Karakteristik bot-like
def calculate_entropy(username):
    # Nama seperti 'user982341' punya entropi rendah dibanding 'AmmarSiraj'
    prob = [float(username.count(c)) / len(username) for c in set(username)]
    entropy = - sum([p * np.log2(p) for p in prob])
    return entropy