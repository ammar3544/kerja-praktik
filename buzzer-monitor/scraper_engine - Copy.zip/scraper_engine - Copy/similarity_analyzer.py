# scraper_engine/similarity_analyzer.py
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer # Memerlukan library ini

class SemanticAnalyzer:
    def __init__(self):
        # Menggunakan model ringan untuk performa cepat di CPU
        self.model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

    def get_features(self, comment_text, batch_texts):
        # 2.1 Semantic Embeddings: Memahami makna konteks
        embedding = self.model.encode([comment_text])
        batch_embeddings = self.model.encode(batch_texts)
        
        # Hitung rata-rata kemiripan dengan komentar lain dalam satu task
        sim_score = cosine_similarity(embedding, batch_embeddings).mean()
        
        # 2.6 Linguistic Analysis: Variasi kosa kata (Type-Token Ratio)
        words = comment_text.lower().split()
        ttr = len(set(words)) / len(words) if len(words) > 0 else 0
        
        return [sim_score, ttr]